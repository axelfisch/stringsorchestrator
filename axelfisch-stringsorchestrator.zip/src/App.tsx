import React, { useState, useMemo } from 'react';
import CircularSelector from './components/CircularSelector';
import RotationControls from './components/RotationControls';
import SelectionPanel from './components/SelectionPanel';

export interface ChordInSequence {
  id: string;
  key: string;
  extension: string;
  bassInversion?: string;
  beat: number;
  position?: 1 | 2;
  style?: string;
}

export interface RotationState {
  styles: number;
  keys: number;
  extensions: number;
  bass: number;
}

const STYLE_LIST = [
  'Bossa',
  'Waltz',
  'ECM',
  'Pop Ballad',
  'Funk',
  'Soul',
  'Smooth',
  'Fusion',
  'Lento',
  'Odd Meter',
  'Free'
];

const EXTENSIONS = [
  'maj7',
  'maj9(#11)',
  '6/9',
  'm7',
  'm9',
  'm11',
  'm(maj7,9)',
  '7(9,13)',
  '7(9,13,#11)',
  'm7b5(11)',
  'sus4(9,13)',
  'add9'
];

function App() {
  const [selectedKey, setSelectedKey] = useState<string>('C');
  const [selectedExtension, setSelectedExtension] = useState<string>('');
  const [selectedBassInversion, setSelectedBassInversion] = useState<string>('');
  const [selectedStyle, setSelectedStyle] = useState<string>(STYLE_LIST[0]);
  const [rotation, setRotation] = useState<RotationState>({
    styles: 0,
    keys: 0,
    extensions: 0,
    bass: 0,
  });
  const [progression, setProgression] = useState<ChordInSequence[]>([]);
  const [bpm, setBpm] = useState<number>(90);

  const fullChordSymbol = useMemo(() => {
    let base = selectedKey || 'C';
    if (selectedExtension) base += selectedExtension.startsWith('/') ? selectedExtension : selectedExtension ? selectedExtension : '';
    if (selectedBassInversion) base += '/' + selectedBassInversion;
    return base;
  }, [selectedKey, selectedExtension, selectedBassInversion]);

  const handleRotate = (ring: keyof RotationState, delta: number) => {
    setRotation(prev => ({ ...prev, [ring]: prev[ring] + delta }));
  };

  const handleKeySelect = (key: string) => {
    setSelectedKey(key);
  };

  const handleExtensionSelect = (ext: string) => {
    setSelectedExtension(ext);
  };

  const handleBassSelect = (bass: string) => {
    setSelectedBassInversion(bass);
  };

  const handleStyleSelect = (style: string) => {
    setSelectedStyle(style);
  };

  const handleAddChordToSequence = () => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const chord: ChordInSequence = {
      id,
      key: selectedKey,
      extension: selectedExtension,
      bassInversion: selectedBassInversion,
      beat: progression.length + 1,
      position: 1,
      style: selectedStyle
    };
    setProgression(prev => [...prev, chord]);
  };

  const handlePlay = () => {
    // Placeholder: branch to your EP sampler / audio engine
    console.log('Play progression at', bpm, 'BPM', progression);
  };

  const handleStop = () => {
    console.log('Stop playback');
  };

  const handleGenerateAxelProgression = () => {
    console.log('Generate AiXEL progression for', selectedKey, selectedStyle);
  };

  return (
    <div className="app-root">
      <header className="app-header">
        <div className="app-header-title">AIXEL · MUSIC ORCHESTRATOR</div>
        <div style={{ fontSize: 12, color: '#9ca3af' }}>
          Circular Harmonic Selector · ECM Chamber Jazz
        </div>
      </header>
      <main className="app-layout">
        <aside className="panel">
          <div className="panel-title">Layer Rotation</div>
          <RotationControls rotation={rotation} onRotate={handleRotate} />
        </aside>
        <section className="panel">
          <div className="panel-title">Circular Selector</div>
          <div className="circle-container">
            <CircularSelector
              selectedKey={selectedKey}
              selectedExtension={selectedExtension}
              selectedBass={selectedBassInversion}
              selectedStyle={selectedStyle}
              styleList={STYLE_LIST}
              extensionList={EXTENSIONS}
              rotation={rotation}
              onKeySelect={handleKeySelect}
              onExtensionSelect={handleExtensionSelect}
              onBassSelect={handleBassSelect}
              onStyleSelect={handleStyleSelect}
            />
          </div>
        </section>
        <aside className="panel">
          <SelectionPanel
            selectedKey={selectedKey}
            selectedExtension={selectedExtension}
            selectedBassInversion={selectedBassInversion}
            selectedStyle={selectedStyle}
            fullChordSymbol={fullChordSymbol}
            onAddChord={handleAddChordToSequence}
            onPlay={handlePlay}
            onStop={handleStop}
            onGenerateAxel={handleGenerateAxelProgression}
            bpm={bpm}
            setBpm={setBpm}
          />
        </aside>
      </main>
    </div>
  );
}

export default App;