import React from 'react';

interface Props {
  selectedKey: string;
  selectedExtension: string;
  selectedBassInversion: string;
  selectedStyle: string;
  fullChordSymbol: string;
  bpm: number;
  setBpm: (bpm: number) => void;
  onAddChord: () => void;
  onPlay: () => void;
  onStop: () => void;
  onGenerateAxel: () => void;
}

const SelectionPanel: React.FC<Props> = ({
  selectedKey,
  selectedExtension,
  selectedBassInversion,
  selectedStyle,
  fullChordSymbol,
  bpm,
  setBpm,
  onAddChord,
  onPlay,
  onStop,
  onGenerateAxel,
}) => {
  return (
    <div>
      <div className="panel-title">Selection</div>
      <div className="selection-field">
        <div className="selection-label">Key</div>
        <div className="selection-value">{selectedKey || '—'}</div>
      </div>
      <div className="selection-field">
        <div className="selection-label">Extension</div>
        <div className="selection-value">{selectedExtension || '—'}</div>
      </div>
      <div className="selection-field">
        <div className="selection-label">Bass inversion</div>
        <div className="selection-value">{selectedBassInversion || '—'}</div>
      </div>
      <div className="selection-field">
        <div className="selection-label">Style</div>
        <div className="selection-value">{selectedStyle || '—'}</div>
      </div>
      <div className="selection-field">
        <div className="selection-label">Full chord</div>
        <div className="selection-value">{fullChordSymbol || '—'}</div>
      </div>

      <div className="selection-field">
        <div className="selection-label">Tempo (BPM)</div>
        <input
          type="number"
          value={bpm}
          onChange={(e) => setBpm(parseInt(e.target.value || '90', 10))}
          style={{
            width: '100%',
            borderRadius: 999,
            border: '1px solid rgba(148,163,184,0.7)',
            background: 'rgba(15,23,42,0.9)',
            color: '#e5e7eb',
            padding: '6px 10px',
            fontSize: 13,
          }}
        />
      </div>

      <div className="button-row">
        <button className="primary-button" type="button" onClick={onPlay}>
          ▶ Play
        </button>
        <button className="secondary-button" type="button" onClick={onStop}>
          ■ Stop
        </button>
      </div>

      <div className="button-row">
        <button className="secondary-button" type="button" onClick={onAddChord}>
          + Add chord to sequence
        </button>
      </div>

      <hr style={{ borderColor: 'rgba(148,163,184,0.25)', margin: '14px 0' }} />

      <div className="selection-field">
        <div className="selection-label">AiXEL Engine</div>
        <div className="selection-value" style={{ fontSize: 13, color: '#9ca3af' }}>
          Uses AiXEL recipes & harmony dictionary to generate ECM-style progressions.
        </div>
      </div>

      <div className="button-row">
        <button className="secondary-button" type="button" onClick={onGenerateAxel}>
          ✦ Generate AiXEL progression
        </button>
      </div>
    </div>
  );
};

export default SelectionPanel;