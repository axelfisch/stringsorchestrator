import React, { useEffect, useRef } from 'react';
import type { RotationState } from '../App';

interface Props {
  selectedKey: string;
  selectedExtension: string;
  selectedBass: string;
  selectedStyle: string;
  styleList: string[];
  extensionList: string[];
  rotation: RotationState;
  onKeySelect: (k: string) => void;
  onExtensionSelect: (e: string) => void;
  onBassSelect: (b: string) => void;
  onStyleSelect: (s: string) => void;
}

const KEYS = ['C','Db','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
const BASS_DEGREES = ['1','b2','2','b3','3','4','#4','5','b6','6','b7','7'];

const CircularSelector: React.FC<Props> = ({
  selectedKey,
  selectedExtension,
  selectedBass,
  selectedStyle,
  styleList,
  extensionList,
  rotation,
  onKeySelect,
  onExtensionSelect,
  onBassSelect,
  onStyleSelect,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const cx = width / 2;
    const cy = height / 2;

    ctx.clearRect(0, 0, width, height);

    // Background
    const bgGrad = ctx.createRadialGradient(cx, cy - 80, 40, cx, cy, width / 1.4);
    bgGrad.addColorStop(0, '#020617');
    bgGrad.addColorStop(1, '#000000');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Helper to draw glowing text
    const drawGlowingText = (
      text: string,
      x: number,
      y: number,
      baseColor: string,
      glowColor: string,
      size: number,
      weight: 'normal' | 'bold' | '600' | '700' = '600'
    ) => {
      ctx.save();
      ctx.font = `${weight} ${size}px system-ui`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Halo
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 18;
      ctx.fillStyle = glowColor;
      ctx.fillText(text, x, y);

      // Second pass
      ctx.shadowColor = 'rgba(255,255,255,0.8)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = baseColor;
      ctx.fillText(text, x, y);

      // Core
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      ctx.fillText(text, x, y);
      ctx.restore();
    };

    // Center circle
    const centerRadius = 120;
    const grad = ctx.createRadialGradient(cx, cy - 40, 20, cx, cy, centerRadius);
    grad.addColorStop(0, '#0b1120');
    grad.addColorStop(1, '#020617');
    ctx.beginPath();
    ctx.arc(cx, cy, centerRadius, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.stroke();

    // KEY label
    ctx.save();
    ctx.font = '600 18px system-ui';
    ctx.fillStyle = '#e5e7eb';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('KEY', cx, cy - 55);
    ctx.restore();

    // Selected key big
    drawGlowingText(selectedKey || 'C', cx, cy - 4, '#e5e7eb', 'rgba(56,189,248,0.9)', 44, '700');

    // Extension
    if (selectedExtension) {
      ctx.save();
      ctx.font = '400 20px system-ui';
      ctx.fillStyle = '#a5b4fc';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(selectedExtension, cx, cy + 34);
      ctx.restore();
    }

    // Generic function to draw a ring of segments with labels
    const drawRing = (
      items: string[],
      rInner: number,
      rOuter: number,
      rotationOffset: number,
      selected: string | null,
      baseColor: string,
      labelColor: string,
      type: 'keys' | 'extensions' | 'bass' | 'styles'
    ) => {
      const count = items.length;
      if (!count) return;
      const angleStep = (Math.PI * 2) / count;
      for (let i = 0; i < count; i++) {
        const angle = -Math.PI / 2 + i * angleStep + rotationOffset;
        const angleNext = angle + angleStep;

        const isSelected = items[i] === selected;

        ctx.beginPath();
        ctx.moveTo(cx + rInner * Math.cos(angle), cy + rInner * Math.sin(angle));
        ctx.arc(cx, cy, rInner, angle, angleNext);
        ctx.lineTo(cx + rOuter * Math.cos(angleNext), cy + rOuter * Math.sin(angleNext));
        ctx.arc(cx, cy, rOuter, angleNext, angle, true);
        ctx.closePath();

        if (type === 'styles' && isSelected) {
          const segGrad = ctx.createLinearGradient(
            cx + rInner * Math.cos(angle),
            cy + rInner * Math.sin(angle),
            cx + rOuter * Math.cos(angleNext),
            cy + rOuter * Math.sin(angleNext)
          );
          segGrad.addColorStop(0, '#0ea5e9');
          segGrad.addColorStop(1, '#3b82f6');
          ctx.fillStyle = segGrad;
        } else {
          ctx.fillStyle = baseColor;
        }
        ctx.fill();

        if (isSelected) {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        const midAngle = angle + angleStep / 2;
        const labelRadius = (rInner + rOuter) / 2;
        const lx = cx + labelRadius * Math.cos(midAngle);
        const ly = cy + labelRadius * Math.sin(midAngle);

        if (type === 'styles') {
          drawGlowingText(items[i], lx, ly, labelColor, 'rgba(96,165,250,0.9)', 14, '700');
        } else {
          ctx.save();
          ctx.font = '500 14px system-ui';
          ctx.fillStyle = labelColor;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(items[i], lx, ly);
          ctx.restore();
        }
      }
    };

    // Draw rings
    drawRing(
      KEYS,
      150,
      190,
      rotation.keys,
      selectedKey,
      '#020617',
      '#e5e7eb',
      'keys'
    );
    drawRing(
      extensionList,
      200,
      240,
      rotation.extensions,
      selectedExtension,
      '#020617',
      '#e5e7eb',
      'extensions'
    );
    drawRing(
      BASS_DEGREES,
      250,
      290,
      rotation.bass,
      selectedBass,
      '#020617',
      '#e5e7eb',
      'bass'
    );
    drawRing(
      styleList,
      310,
      360,
      rotation.styles,
      selectedStyle,
      '#020617',
      '#60a5fa',
      'styles'
    );
  }, [
    selectedKey,
    selectedExtension,
    selectedBass,
    selectedStyle,
    styleList,
    extensionList,
    rotation.keys,
    rotation.extensions,
    rotation.bass,
    rotation.styles,
  ]);

  const handleClick: React.MouseEventHandler<HTMLCanvasElement> = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const dx = x - cx;
    const dy = y - cy;
    const r = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(dy, dx);

    const normAngle = (angle + Math.PI * 2 + Math.PI / 2) % (Math.PI * 2);

    const inRing = (rInner: number, rOuter: number) => r >= rInner && r <= rOuter;

    const pickIndex = (count: number, rotationOffset: number) => {
      const step = (Math.PI * 2) / count;
      const a = (normAngle - rotationOffset + Math.PI * 2) % (Math.PI * 2);
      return Math.floor(a / step);
    };

    // Styles ring
    if (inRing(310, 360)) {
      const idx = pickIndex(styleList.length, rotation.styles);
      const style = styleList[idx];
      if (style) onStyleSelect(style);
      return;
    }

    // Bass ring
    if (inRing(250, 290)) {
      const idx = pickIndex(BASS_DEGREES.length, rotation.bass);
      const bass = BASS_DEGREES[idx];
      if (bass) onBassSelect(bass);
      return;
    }

    // Extensions
    if (inRing(200, 240)) {
      if (extensionList.length) {
        const idx = pickIndex(extensionList.length, rotation.extensions);
        const ext = extensionList[idx];
        if (ext) onExtensionSelect(ext);
      }
      return;
    }

    // Keys
    if (inRing(150, 190)) {
      const idx = pickIndex(KEYS.length, rotation.keys);
      const key = KEYS[idx];
      if (key) onKeySelect(key);
      return;
    }
  };

  return (
    <canvas
      ref={canvasRef}
      className="circular"
      style={{ width: '100%', height: '100%', maxWidth: 600, maxHeight: 600 }}
      onClick={handleClick}
    />
  );
};

export default CircularSelector;