import React from 'react';
import type { RotationState } from '../App';

interface Props {
  rotation: RotationState;
  onRotate: (ring: keyof RotationState, delta: number) => void;
}

const RotationControls: React.FC<Props> = ({ rotation, onRotate }) => {
  const groups: { id: keyof RotationState; label: string; color: string }[] = [
    { id: 'styles', label: 'Styles', color: '#60a5fa' },
    { id: 'keys', label: 'Keys', color: '#4ade80' },
    { id: 'extensions', label: 'Extensions', color: '#a855f7' },
    { id: 'bass', label: 'Bass', color: '#22c55e' },
  ];

  const step = (ring: keyof RotationState) => {
    switch (ring) {
      case 'styles':
        return (2 * Math.PI) / 11;
      case 'keys':
      case 'bass':
        return (2 * Math.PI) / 12;
      case 'extensions':
        return (2 * Math.PI) / 12;
      default:
        return 0.1;
    }
  };

  return (
    <div>
      {groups.map(group => (
        <div key={group.id} className="rotation-group">
          <span className="rotation-label" style={{ color: group.color }}>
            {group.label}
          </span>
          <div className="rotation-buttons">
            <button
              className="icon-button"
              onClick={() => onRotate(group.id, step(group.id))}
              type="button"
            >
              ‹
            </button>
            <button
              className="icon-button"
              onClick={() => onRotate(group.id, -step(group.id))}
              type="button"
            >
              ›
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RotationControls;