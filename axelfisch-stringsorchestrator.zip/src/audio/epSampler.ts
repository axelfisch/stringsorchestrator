import * as Tone from 'tone';

let sampler: Tone.Sampler | null = null;

export async function getEPSampler() {
  if (sampler) return sampler;

  sampler = new Tone.Sampler(
    {
      C3: 'EP_C3.wav',
      F3: 'EP_F3.wav',
      'A#3': 'EP_A#3.wav',
      D4: 'EP_D4.wav',
      F4: 'EP_F4.wav',
      'A#4': 'EP_A#4.wav',
    },
    {
      baseUrl: '/samples/epiano/',
    }
  ).toDestination();

  await Tone.loaded();
  return sampler;
}