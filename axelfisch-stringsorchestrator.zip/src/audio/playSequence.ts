import * as Tone from 'tone';
import { getEPSampler } from './epSampler';

export type NoteEvent = {
  time: number;      // seconds or beats depending on mapping
  notes: string[];   // ex: ['F3','A3','C4']
  duration: number;  // seconds or beats
};

export async function playSequence(events: NoteEvent[], bpm = 90) {
  if (!events.length) return;

  await Tone.start();
  const sampler = await getEPSampler();

  Tone.Transport.stop();
  Tone.Transport.cancel();
  Tone.Transport.position = 0;
  Tone.Transport.bpm.value = bpm;

  events.forEach((event) => {
    const timeInSeconds = event.time; // adapt as needed
    const timeInBeats = (timeInSeconds * bpm) / 60;

    Tone.Transport.schedule((time) => {
      sampler.triggerAttackRelease(event.notes, event.duration, time);
    }, timeInBeats);
  });

  Tone.Transport.start('+0.1');
}

export function stopSequence() {
  Tone.Transport.stop();
}