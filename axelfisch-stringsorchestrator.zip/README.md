# AiXEL Music Orchestrator · Circular Selector

Prototype React+Vite project for the circular harmonic selector used by Axel Fisch.

## Structure

- `src/App.tsx` – three-column layout (rotation controls · circular selector · selection panel)
- `src/components/CircularSelector.tsx` – canvas-based multi-ring selector (Styles / Keys / Extensions / Bass)
- `src/components/RotationControls.tsx` – left-side controls for rotating each ring
- `src/components/SelectionPanel.tsx` – right-side current selection + actions (Play / Stop / Generate AiXEL progression)
- `src/audio/epSampler.ts` – Tone.js-based Electric Piano sampler
- `src/audio/playSequence.ts` – basic playback utilities
- `public/samples/epiano/` – put your EP samples here

## Getting started

```bash
npm install
npm run dev
```

Then open http://localhost:5173

## Next steps

- Wire `playSequence` into `App.handlePlay` using AiXEL harmony dictionary to generate NoteEvent[]
- Connect `handleGenerateAxelProgression` to your backend or GPT (AIXEL_MASTER_MODEL_2025_FULL_v2.json)