# EP Sampler Samples

Place your Electric Piano (Rhodes-style) samples here.

Expected files (can be .wav or .mp3, but must match epSampler.ts mapping):

- EP_C3.wav
- EP_F3.wav
- EP_A#3.wav
- EP_D4.wav
- EP_F4.wav
- EP_A#4.wav

Keep them short, well trimmed, and normalized. 44.1 kHz / 16-bit is fine.